<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://algox360.com/
 * @since      1.0.0
 *
 * @package    Algox_360targetprofilo
 * @subpackage Algox_360targetprofilo/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Algox_360targetprofilo
 * @subpackage Algox_360targetprofilo/includes
 * @author     Sandeep Choudhary <sandeepchoudhary85@gmail.com>
 */
class Algox_360targetprofilo_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
	
	}

}
