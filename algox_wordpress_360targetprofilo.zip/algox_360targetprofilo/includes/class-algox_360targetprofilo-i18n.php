<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://https://algox360.com/
 * @since      1.0.0
 *
 * @package    Algox_360targetprofilo
 * @subpackage Algox_360targetprofilo/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Algox_360targetprofilo
 * @subpackage Algox_360targetprofilo/includes
 * @author     Sandeep Choudhary <sandeepchoudhary85@gmail.com>
 */
class Algox_360targetprofilo_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'algox_360targetprofilo',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
