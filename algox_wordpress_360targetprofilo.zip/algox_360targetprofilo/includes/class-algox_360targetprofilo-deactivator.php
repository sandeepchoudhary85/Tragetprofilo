<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://algox360.com/
 * @since      1.0.0
 *
 * @package    Algox_360targetprofilo
 * @subpackage Algox_360targetprofilo/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Algox_360targetprofilo
 * @subpackage Algox_360targetprofilo/includes
 * @author     Sandeep Choudhary <sandeepchoudhary85@gmail.com>
 */
class Algox_360targetprofilo_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
