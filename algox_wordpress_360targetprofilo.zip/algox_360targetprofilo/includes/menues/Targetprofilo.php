<?php  $plugin_dir = plugins_url() . '/algox_360targetprofilo/'; ?>
<link rel='stylesheet' id='woocommerce_admin_menu_styles-css' href='<?php echo $plugin_dir ?>admin/css/algox_360targetprofilo-admin.css' media='all' />
  
  <div class="api-text-area">
    <div class="container">

    
  <div class="img-logo">
    <img src="<?php  echo plugin_dir_url( __DIR__  ) ?>img/logo1.png" alt="">
  </div>
        
   
    <h1>Api Key</h1>
    
<?php  if(isset($_POST['updatetoken'])) { 
    
    $getToken = $_POST['token'];

    update_option( 'targetprofilo_api', $getToken );

}?>        

<form action="<?php echo $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'] ?>" method="POST">
         <input type="text" value="<?php echo get_option('targetprofilo_api'); ?>" name="token">
         <input type="hidden" value="my-menu-slug" name="page" />
         <input class="submit-btn" type="submit" value="Update" name="updatetoken">
        
         </form>
         </div>

        
  </div>
 
      
    
