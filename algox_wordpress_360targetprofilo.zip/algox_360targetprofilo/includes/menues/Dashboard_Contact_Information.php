<?php  $plugin_dir = plugins_url() . '/algox_360targetprofilo/'; ?>
<link rel='stylesheet' id='woocommerce_admin_menu_styles-css' href='<?php echo $plugin_dir ?>admin/css/algox_360targetprofilo-admin.css' media='all' />

    <div class="data-transfer">
    <div class="container">


<div class="img-logo">
    <img src="<?php  echo plugin_dir_url( __DIR__  ) ?>img/logo1.png" alt="">
</div>
<?php 

global $wpdb;

//$wpdb->show_errors();
$query = $wpdb->get_results("SELECT * FROM wp_target_profile_contact");
//$result = $wpdb->query($query);
//echo $wpdb->last_query; die;
//echo "<pre>";print_r($query);
?>

        <div class="table-r">
            <table class="table custom-table">
                <thead>

               
                    <tr>
                        
                        <th scope="col">First NAME</th>
                        <th scope="col">Last NAME</th>
                        <th scope="col">Address</th>
                        <th scope="col">Email</th>
                        <th scope="col">Company</th>
                        <th scope="col">Phone</th>
                        <th scope="col">CREATED</th>
                        <th scope="col">LAST UPDATED</th>
                    </tr>
                    </div>
                </thead>
                <tbody>

                <?php foreach($query as $query_value) : 
                   // $user_info = get_userdata($query_value->user_id);
                    ?>
                    <tr>
                        
                        <td><?php echo $query_value->first_name;?></td>
                        <td><?php echo $query_value->last_name;?></td>
                        <td><?php echo $query_value->address;?></td>
                        <td><?php echo $query_value->email;?></td>
                        <td><?php echo $query_value->company;?></td>
                        <td><?php echo $query_value->phone;?></td>
                        <td><?php echo date("Y-m-d h:m:s ", strtotime($query_value->created_on)); ?></td>
                        <td><?php echo date("Y-m-d h:m:s ", strtotime($query_value->updated_on)); ?></td>
                        
                    </tr>
                <?php endforeach; ?>    
                    
                </tbody>
            </table>
        </div>
    </div>
    <style>


.custom-table thead tr, .custom-table thead th {
    padding-left: 16px !important;
}
    
.table tbody td {
    padding: 11px 15px;
}

    </style>
    </div>