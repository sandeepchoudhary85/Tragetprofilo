<?php  $plugin_dir = plugins_url() . '/algox_360targetprofilo/'; ?>
<link rel='stylesheet' id='woocommerce_admin_menu_styles-css' href='<?php echo $plugin_dir ?>admin/css/algox_360targetprofilo-admin.css' media='all' />

    <div class="data-transfer">
    <div class="container">
        <div class="img-logo">
    <img src="<?php  echo plugin_dir_url( __DIR__  ) ?>img/logo1.png" alt="">
    </div>
    <?php 

$gettoken = get_option('targetprofilo_api');
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api-dev.targetprofilo.com/api/v1/recipient-lists',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'x-api-key: '.$gettoken
  ),
));

$response = curl_exec($curl);

curl_close($curl);
//var_dump($response);

$decoded_traces=json_decode($response, true);
//echo "<pre>";
//print_r($decoded_traces);
    

    ?>
        <div class="table-r">
            <table class="table custom-table">
                <thead>
                    <tr>
                        <th scope="col">
                            <label class="control-1 ">
                                <input type="checkbox" id="ckbCheckAll">
                                <div class="control-1__indicator"></div>
                            </label>
                        </th>
                        <th scope="col">NAME</th>
                        <th scope="col">TYPE</th>
                        <th scope="col">
                            DOUBLE OPTED-IN</th>
                        <th scope="col">
                        id</th>
                        <th scope="col">CREATED</th>
                        <th scope="col">LAST UPDATED </th>
                    </tr>
                </thead>
                <tbody>

                <?php     foreach($decoded_traces['results'] as $decoded_traces_value) :   
                    
                    $originalDate = $decoded_traces_value['createdAt'];
                   $createdAt = date("Y-m-d h:m:s ", strtotime($originalDate));

                   $originalDate_updatedAt = $decoded_traces_value['updatedAt'];
                   $updatedAt = date("Y-m-d h:m:s ", strtotime($originalDate_updatedAt));

                    ?>
                    <tr>
                        <th scope="row">
                            <label class="control-1 ">
                                <input type="checkbox" class="checkBoxClass" id="Checkbox1">
                                <div class="control-1__indicator"></div>
                            </label>
                        </th>
                        <td><?php echo $decoded_traces_value['name']; ?></td>
                        <td><?php echo @$decoded_traces_value['type']; ?></td>
                        <td><?php echo $decoded_traces_value['dblOptIn']; ?></td>
                        <td><?php echo $decoded_traces_value['id']; ?></td>
                        <td><?php echo $createdAt ?></td>
                        <td><?php echo $updatedAt; ?></td>
                    </tr>

                <?php endforeach;?>    
                    
                </tbody>
            </table>
        </div>
    </div>
    </div>



      

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $("#ckbCheckAll").click(function() {
        $(".checkBoxClass").attr('checked', this.checked);
    });
});


$(document).click(function() { 
        if($('.menu').is(":visible")) {
            $('.menu').hide()
        }      
});
</script>
