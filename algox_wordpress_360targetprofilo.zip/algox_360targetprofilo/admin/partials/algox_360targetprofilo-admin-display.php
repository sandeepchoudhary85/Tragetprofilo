<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://algox360.com/
 * @since      1.0.0
 *
 * @package    Algox_360targetprofilo
 * @subpackage Algox_360targetprofilo/admin/partials
 */


?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
