<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://https://algox360.com/
 * @since             1.0.0
 * @package           Algox_360targetprofilo
 *
 * @wordpress-plugin
 * Plugin Name:       Algox360_Targetprofilo
 * Plugin URI:        https://https://algox360.com/
 * Description:       The WordPress plugin will provide seamless integration between a user's WordPress website and the TargetProfilo marketing platform, enabling them to efficiently handle contact form submissions, transfer data, track pages and blogs, and stay updated with contact information within the WordPress dashboard.
 * Version:           1.0.0
 * Author:            Sandeep Choudhary
 * Author URI:        https://https://algox360.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       algox_360targetprofilo
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


/*
add_action( 'admin_init', 'algox_360targetprofilo_check_if_woocommerce_installed' );
function algox_360targetprofilo_check_if_woocommerce_installed() {

    // If WooCommerce is NOT installed, Deactivate the plugin
    if ( is_admin() && current_user_can( 'activate_plugins') && !is_plugin_active( 'woocommerce/woocommerce.php') ) {

        // Show dismissible error notice
        add_action( 'admin_notices', 'algox_360targetprofilo_woocommerce_check_notice' );

        // Deactivate this plugin
        deactivate_plugins( plugin_basename( __FILE__) );
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
    }
    // If WooCommerce is installed, activate the plugin and carry out further processing
    elseif ( is_admin() && is_plugin_active( 'woocommerce/woocommerce.php') ) {

        // Carry out further processing here
    }
}

// Show dismissible error notice if WooCommerce is not present
function algox_360targetprofilo_woocommerce_check_notice() {
    ?>
    <div class="alert alert-danger notice is-dismissible"  style="font-weight: bold;color: #ea0d0d;">
        <p>Sorry, but Targetprofilo requires WooCommerce in order to work.
            So please ensure that WooCommerce is both installed and activated.
        </p>
    </div>
    <?php
}
*/


/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'ALGOX_360TARGETPROFILO_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-algox_360targetprofilo-activator.php
 */

function activate_algox_360targetprofilo() {

	require_once plugin_dir_path( __FILE__ ) . 'includes/class-algox_360targetprofilo-activator.php';
	Algox_360targetprofilo_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-algox_360targetprofilo-deactivator.php
 */
function deactivate_algox_360targetprofilo() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-algox_360targetprofilo-deactivator.php';
	Algox_360targetprofilo_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_algox_360targetprofilo' );
register_deactivation_hook( __FILE__, 'deactivate_algox_360targetprofilo' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */

//  function css_and_js_admin(){
// 	require_once plugin_dir_path( __FILE__ ) . 'admin/class-algox_360targetprofilo-admin.php';
// 		$css = new Algox_360targetprofilo_Admin();
//  }
//  css_and_js_admin();


require plugin_dir_path( __FILE__ ) . 'includes/class-algox_360targetprofilo.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_algox_360targetprofilo() {

	$plugin = new Algox_360targetprofilo();
	//$plugin->run();

}

run_algox_360targetprofilo();
















/*********************************************************************/
/* Add featured post checkbox for the pages and Posts 
/********************************************************************/
add_action( 'add_meta_boxes', 'add_featured_checkbox_function' );
function add_featured_checkbox_function() {
   add_meta_box('featured_checkbox_id','FEATURED POST ?', 'featured_checkbox_callback_function', 'post', 'normal', 'high');
   add_meta_box('featured_checkbox_id','FEATURED POST ?', 'featured_checkbox_callback_function', 'page', 'normal', 'high');
}
function featured_checkbox_callback_function( $post ) {
   global $post;

   $brand_awareness = get_post_meta( $post->ID, 'tracking_option_category', true );
   $lead_generation = get_post_meta( $post->ID, 'tracking_option_category', true );
   $lead_nurturing = get_post_meta( $post->ID, 'tracking_option_category', true );
   $lead_conversion = get_post_meta( $post->ID, 'tracking_option_category', true );
   $repeat_conversion = get_post_meta( $post->ID, 'tracking_option_category', true );
   $generate_loyalty = get_post_meta( $post->ID, 'tracking_option_category', true );


?>
   
   <input type="radio" name="tracking_option_category" value="brand_awareness" <?php echo (($brand_awareness == 'brand_awareness') ? 'checked="checked"': '');?>/> Brand Awareness
   <input type="radio" name="tracking_option_category" value="lead_generation" <?php echo (($lead_generation == 'lead_generation') ? 'checked="checked"': '');?>/> Lead Generation
   <input type="radio" name="tracking_option_category" value="lead_nurturing" <?php echo (($lead_nurturing == 'lead_nurturing') ? 'checked="checked"': '');?>/>  Lead Nurturing
   <input type="radio" name="tracking_option_category" value="lead_conversion" <?php echo (($lead_conversion == 'lead_conversion') ? 'checked="checked"': '');?>/> Lead Conversion
   <input type="radio" name="tracking_option_category" value="repeat_conversion" <?php echo (($repeat_conversion == 'repeat_conversion') ? 'checked="checked"': '');?>/> Repeat Conversion
   <input type="radio" name="tracking_option_category" value="generate_loyalty" <?php echo (($generate_loyalty == 'generate_loyalty') ? 'checked="checked"': '');?>/> Generate Loyalty

   
<?php
}

add_action('save_post', 'save_featured_post'); 
function save_featured_post($post_id){ 
if(isset($_POST['action'])){
	update_post_meta( $post_id, 'tracking_option_category', $_POST['tracking_option_category']); 
}

}




/*********************************************************************/
/* Front end Code Start Here 
/********************************************************************/

/////// Add Data Into database after order place 
add_action('woocommerce_thankyou', 'enroll_student', 10, 1);
function enroll_student( $order_id ) {

    if ( ! $order_id )
        return;

    // Getting an instance of the order object
    $order = wc_get_order( $order_id );

    // Get the Customer ID (User ID)
$customer_id = $order->get_customer_id(); // Or $order->get_user_id();

// Get the WP_User Object instance
$user = $order->get_user();

// Get the WP_User roles and capabilities
//$user_roles = $user->roles;

// Get the Customer billing email
$billing_email  = $order->get_billing_email();

// Get the Customer billing phone
 $billing_phone  = $order->get_billing_phone();

// Customer billing information details
$billing_first_name = $order->get_billing_first_name();
$billing_last_name  = $order->get_billing_last_name();
$billing_company    = $order->get_billing_company();
$billing_address_1  = $order->get_billing_address_1();
$billing_address_2  = $order->get_billing_address_2();
$billing_city       = $order->get_billing_city();
$billing_state      = $order->get_billing_state();
$billing_postcode   = $order->get_billing_postcode();
$billing_country    = $order->get_billing_country();

global $wpdb;
$tablename = $wpdb->prefix . "target_profile_contact";

$sql = "SELECT * FROM `$tablename` WHERE `email` = '$billing_email'";
$result = $wpdb->get_results($sql);
$checkcustomer =  count($result);

$exists = email_exists( $billing_email );
if ( $exists  || $checkcustomer > 0) {
//echo "UPDATE `$tablename` SET `first_name`='".$billing_first_name."',`last_name`='".$billing_last_name."',`address`='".$billing_address_1."',`country`='".$billing_country."',`city`='".$billing_city."',`state`='".$billing_state."',`pin`=$billing_postcode, `company`='".$billing_company."',`phone`= $billing_phone,`updated_on`=NOW() WHERE `email` = '".$billing_email."'";
 $sql = $wpdb->prepare("UPDATE `$tablename` SET `first_name`='".$billing_first_name."',`last_name`='".$billing_last_name."',`address`='".$billing_address_1."',`country`='".$billing_country."',`city`='".$billing_city."',`state`='".$billing_state."',`pin`=$billing_postcode, `company`='".$billing_company."',`phone`= $billing_phone,`updated_on`=NOW() WHERE `email` = '".$billing_email."'");
} else {
	
   $sql = $wpdb->prepare("INSERT INTO `$tablename`(`id`, `first_name`, `last_name`, `address`, `country`, `city`, `state`, `pin`, `email`, `company`, `phone`, `created_on`, `updated_on`) 
VALUES ('' ,'".$billing_first_name."','".$billing_last_name."','".$billing_address_1."','".$billing_country."','".$billing_city."','".$billing_state."',$billing_postcode,'".$billing_email."','".$billing_company."',$billing_phone,NOW(),NOW())");

        //////// Send Data to target profilo 
$profilearray = array();
$profilearray['firstName'] = $billing_first_name;
$profilearray['lastName'] = $billing_last_name;
$profilearray['company'] = $billing_company;
$profilearray['email'] = $billing_email;
$profilearray['title'] = 'From Woocomerce';
$profilearray['phone'] = $billing_phone;
$profilearray['address'] = $billing_address_1;
$profilearray['country'] = $billing_country;
$profilearray['city'] = $billing_city;
$profilearray['state'] = $billing_state;
$profilearray['zip'] = $billing_postcode;

$echoprofilefields =  json_encode($profilearray);
$getapikey = get_option('targetprofilo_api');
        $curl = curl_init();

                curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://api-dev.targetprofilo.com/api/v1/recipients',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS =>$echoprofilefields,
                CURLOPT_HTTPHEADER => array(
                    'x-api-key: '.$getapikey,
                    'Content-Type: application/json'
                ),
                ));

                $response = curl_exec($curl);

                curl_close($curl);
                echo $response;
}

$wpdb->query($sql);

// Customer shipping information details
// $shipping_first_name = $order->get_shipping_first_name();
// $shipping_last_name  = $order->get_shipping_last_name();
// $shipping_company    = $order->get_shipping_company();
// $shipping_address_1  = $order->get_shipping_address_1();
// $shipping_address_2  = $order->get_shipping_address_2();
// $shipping_city       = $order->get_shipping_city();
// $shipping_state      = $order->get_shipping_state();
// $shipping_postcode   = $order->get_shipping_postcode();
// $shipping_country    = $order->get_shipping_country();  

}



//////////// User Page Tracking...

add_action('template_redirect', 'showid');

function showid(){
    global $wp_query;
    $theid = intval(@$wp_query->queried_object->ID);
   // echo  $theid;
    $userid = get_current_user_id();


///// Database manupulation for tracking.....

$browser = '';
$ipaddress = ''; 


    global $wpdb;
    $tablename = $wpdb->prefix . "target_profile_tracking";
    
    $sql = "SELECT * FROM `$tablename` WHERE `user_id` = '$userid' AND `page_id` = '$theid' ";
    $result_tracking = $wpdb->get_results($sql);
   $check_tracking =  count($result_tracking);
   $counter = 1;
//echo "<pre>"; print_r( $result_tracking);
   if ($check_tracking > 0) { 

    $counter = $result_tracking['0']->counter + 1 ;

    $sql = $wpdb->prepare("UPDATE `$tablename` SET `counter`='".$counter."',`ip_address`='".$ipaddress."',`browser`='".$browser."' ,`last_visit`= NOW() WHERE `user_id` = '$userid' AND `page_id` = '$theid' ");

   }
   else{
    if ($userid & $theid) { 
    $sql = $wpdb->prepare("INSERT INTO `$tablename`(`id`, `user_id`, `page_id`, `counter`, `ip_address`, `browser`, `first_visit`, `last_visit`) 
    VALUES ('' ,'".$userid."','".$theid."' ,'".$counter."','".$ipaddress."','".$browser."',NOW(),NOW())");
    }
}
    $wpdb->query($sql);
}
